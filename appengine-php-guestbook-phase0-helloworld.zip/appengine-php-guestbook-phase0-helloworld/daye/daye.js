$(document).ready(function(){
    $('#skeleton').animate({right: '+=1000px' },1000);
});
